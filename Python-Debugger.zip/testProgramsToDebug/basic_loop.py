#!/usr/bin/env python3


a = 0
for i in range(10):
    a = a + i
print(a)
