#!/usr/bin/env python3

a = int(input())
b = int(input())
c = a + b
print(c)
