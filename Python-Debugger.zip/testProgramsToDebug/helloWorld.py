#!/usr/bin/env python3


def hello_world():
    hello_string = "Hello World!"
    print(hello_string)


hello_world()
