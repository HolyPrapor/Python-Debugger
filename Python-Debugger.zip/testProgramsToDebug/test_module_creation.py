import testProgramsToDebug.test_module_with_class

a = testProgramsToDebug.test_module_with_class.TestClass()

print("SUCCESS")
