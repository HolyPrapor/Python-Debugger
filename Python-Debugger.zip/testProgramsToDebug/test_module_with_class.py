class TestClass:
    def __init__(self):
        print("CREATED")
