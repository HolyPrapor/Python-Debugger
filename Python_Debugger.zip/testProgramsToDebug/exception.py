#!/usr/bin/env python3

raise Exception
